package com.microservice.demo.customer.cutomerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CutomerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CutomerServiceApplication.class, args);
	}

}
