package com.microservice.demo.customer.cutomerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CutomerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
